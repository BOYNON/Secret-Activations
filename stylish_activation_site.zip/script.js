async function submitCode() {
    const code = document.getElementById("code").value;
    const response = await fetch("/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code })
    });

    const data = await response.json();
    if (data.success) {
        window.location.href = data.download_link;
    } else {
        document.getElementById("message").innerText = "Invalid or used code!";
    }
}
